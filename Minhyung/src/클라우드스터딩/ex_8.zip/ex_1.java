package Ŭ���彺�͵�;

public class ex_1 {

	public static void main(String[] args) {
		System.out.println("Hello world!!");
	}

}
