package ����;

public class Coding_10_atm {
	
private int money;

public int getMoney() {
	return money;
}

public void setMoney(int money) {
	this.money = money;
}
}
