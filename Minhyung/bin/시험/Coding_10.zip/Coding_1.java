package ����;

public class Coding_1 {

	public static void main(String[] args) {
		int val_1=83;
      double val_2=2.0;
      double result= val_1/val_2;
      System.out.println(result);
      
	}
}
